package UI;

import javax.swing.*;

import entity.ThuThu;
import service.ThuThuService;

import java.awt.*;

public class DangNhap extends JFrame {
    private JTextField txtTaiKhoan;
    private JPasswordField txtMatKhau;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                DangNhap frame = new DangNhap();
                frame.setVisible(true);
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    public DangNhap() {
        setTitle("Đăng Nhập - Thư Viện STU");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null); 
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("ĐĂNG NHẬP HỆ THỐNG", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(lblTitle, BorderLayout.NORTH);

        JPanel pForm = new JPanel(new GridLayout(2, 2, 10, 20));
        pForm.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        
        pForm.add(new JLabel("Tài Khoản:"));
        txtTaiKhoan = new JTextField();
        pForm.add(txtTaiKhoan);
        
        pForm.add(new JLabel("Mật Khẩu:"));
        txtMatKhau = new JPasswordField();
        pForm.add(txtMatKhau);
        add(pForm, BorderLayout.CENTER);

        JPanel pBtn = new JPanel();
        JButton btnLogin = new JButton("Đăng Nhập");
        btnLogin.setFont(new Font("Tahoma", Font.BOLD, 14));
        pBtn.add(btnLogin);
        add(pBtn, BorderLayout.SOUTH);

        btnLogin.addActionListener(e -> kiemTraDangNhap());
    }

    private void kiemTraDangNhap() {
        String taiKhoan = txtTaiKhoan.getText().trim();
        String matKhau  = new String(txtMatKhau.getPassword()).trim();

        if (taiKhoan.isEmpty() || matKhau.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Vui lòng nhập tài khoản và mật khẩu!");
            return;
        }

        ThuThuService service = new ThuThuService();
        ThuThu thuThu = service.dangNhap(taiKhoan, matKhau);

        if (thuThu != null) {
            // Populate the Auth static fields your UI already uses
            Auth.maThuThu  = thuThu.getMaThuThu();
            Auth.tenThuThu = thuThu.getTenThuThu();
            Auth.vaiTro    = thuThu.getVaiTro();

            // Open main window, close login
            new index().setVisible(true);
            dispose();
        } else {
            JOptionPane.showMessageDialog(null,
                "Tài khoản hoặc mật khẩu không đúng!", "Lỗi đăng nhập",
                JOptionPane.ERROR_MESSAGE);
            txtMatKhau.setText("");
            txtTaiKhoan.requestFocus();
        }
    }
}
