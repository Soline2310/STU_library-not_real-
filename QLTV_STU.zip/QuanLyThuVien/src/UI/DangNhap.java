package UI;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DangNhap extends JFrame {
    private JTextField txtTaiKhoan;
    private JPasswordField txtMatKhau;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                DangNhap frame = new DangNhap();
                frame.setVisible(true);
            } catch (Exception e) { e.printStackTrace(); }
        });
    }

    public DangNhap() {
        setTitle("Đăng Nhập - Thư Viện STU");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 250);
        setLocationRelativeTo(null); 
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("ĐĂNG NHẬP HỆ THỐNG", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        add(lblTitle, BorderLayout.NORTH);

        JPanel pForm = new JPanel(new GridLayout(2, 2, 10, 20));
        pForm.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        
        pForm.add(new JLabel("Tài Khoản:"));
        txtTaiKhoan = new JTextField();
        pForm.add(txtTaiKhoan);
        
        pForm.add(new JLabel("Mật Khẩu:"));
        txtMatKhau = new JPasswordField();
        pForm.add(txtMatKhau);
        add(pForm, BorderLayout.CENTER);

        JPanel pBtn = new JPanel();
        JButton btnLogin = new JButton("Đăng Nhập");
        btnLogin.setFont(new Font("Tahoma", Font.BOLD, 14));
        pBtn.add(btnLogin);
        add(pBtn, BorderLayout.SOUTH);

        btnLogin.addActionListener(e -> kiemTraDangNhap());
    }

    private void kiemTraDangNhap() {
        String tk = txtTaiKhoan.getText();
        String mk = new String(txtMatKhau.getPassword());

        String dbUrl = "jdbc:mysql://localhost:3306/QuanLyThuVienSTU?useUnicode=true&characterEncoding=UTF-8";
        String dbUser = "root"; 
        String dbPass = ""; 

        try (Connection con = DriverManager.getConnection(dbUrl, dbUser, dbPass)) {
            String sql = "SELECT MaThuThu, TenThuThu, VaiTro FROM THU_THU WHERE TaiKhoan = ? AND MatKhau = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, tk);
            pst.setString(2, mk);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                Auth.maThuThu = rs.getString("MaThuThu");
                Auth.tenThuThu = rs.getString("TenThuThu");
                Auth.vaiTro = rs.getString("VaiTro");

                JOptionPane.showMessageDialog(this, "Đăng nhập thành công với quyền: " + Auth.vaiTro);
                
                index mainForm = new index();
                mainForm.setExtendedState(JFrame.MAXIMIZED_BOTH);
                mainForm.setVisible(true);
                this.dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Sai tài khoản hoặc mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi kết nối CSDL!");
        }
    }
}